
# COVID-19 Data Analysis using Python

This project performs data analysis on COVID-19 dataset using Python libraries like Pandas, Seaborn, and Matplotlib.

## Dataset
- Source: [COVID-19 Dataset](https://raw.githubusercontent.com/SR1608/Datasets/main/covid-data.csv)

## Features
- Data Cleaning & Preprocessing
- Data Aggregation & Grouping
- Feature Engineering
- Visualizations using seaborn and matplotlib

## Visualizations
- Histogram
- Scatter Plot
- Pair Plot
- Bar Plot

## Output
- Aggregated file: `df_groupby.csv`

## How to Run
```bash
pip install pandas numpy seaborn matplotlib
python covid_analysis.py
```

---
Project created by Atul Kumar.

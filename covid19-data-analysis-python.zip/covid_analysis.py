
# covid_analysis.py

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

url = "https://raw.githubusercontent.com/SR1608/Datasets/main/covid-data.csv"
df = pd.read_csv(url)

print("\nShape of dataset (rows, columns):", df.shape)
print("\nData types:\n", df.dtypes)
print("\nData Info:")
print(df.info())
print("\nData Description:")
print(df.describe(include='all'))

print("\nUnique locations:", df['location'].nunique())
print("\nContinent with max frequency:\n", df['continent'].value_counts().idxmax())
print("\nMax total_cases:", df['total_cases'].max())
print("Mean total_cases:", df['total_cases'].mean())

print("\nQuartiles for total_deaths:")
print(df['total_deaths'].quantile([0.25, 0.5, 0.75]))

print("\nContinent with max Human Development Index:")
print(df.loc[df['human_development_index'].idxmax()]['continent'])

print("\nContinent with min GDP per capita:")
print(df.loc[df['gdp_per_capita'].idxmin()]['continent'])

df = df[['continent', 'location', 'date', 'total_cases', 'total_deaths', 'gdp_per_capita', 'human_development_index']]
df.drop_duplicates(inplace=True)
print("\nMissing values in each column:\n", df.isnull().sum())

df = df.dropna(subset=['continent'])
df.fillna(0, inplace=True)

df['date'] = pd.to_datetime(df['date'])
df['month'] = df['date'].dt.month

df_groupby = df.groupby('continent').max().reset_index()
print("\nAggregated DataFrame:\n", df_groupby)

df_groupby['total_deaths_to_total_cases'] = df_groupby['total_deaths'] / df_groupby['total_cases']

sns.set(style="darkgrid")

plt.figure(figsize=(8, 4))
sns.histplot(df['gdp_per_capita'], kde=True, color='purple')
plt.title("Distribution of GDP per Capita")
plt.xlabel("GDP per Capita")
plt.show()

plt.figure(figsize=(8, 6))
sns.scatterplot(x='total_cases', y='gdp_per_capita', data=df)
plt.title("Total Cases vs GDP per Capita")
plt.show()

sns.pairplot(df_groupby)
plt.suptitle("Pairplot for df_groupby", y=1.02)
plt.show()

sns.catplot(x='continent', y='total_cases', kind='bar', data=df_groupby, height=5, aspect=2)
plt.title("Total Cases per Continent")
plt.xticks(rotation=45)
plt.show()

df_groupby.to_csv("df_groupby.csv", index=False)
print("\ndf_groupby saved as 'df_groupby.csv'")
